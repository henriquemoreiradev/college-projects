package br.com.abellabank.terminal.conta;

public class Conta {

}



