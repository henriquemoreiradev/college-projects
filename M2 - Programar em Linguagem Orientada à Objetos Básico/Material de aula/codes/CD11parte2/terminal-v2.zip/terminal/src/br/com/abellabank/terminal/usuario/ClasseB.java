package br.com.abellabank.terminal.usuario;

public class ClasseB {
}



