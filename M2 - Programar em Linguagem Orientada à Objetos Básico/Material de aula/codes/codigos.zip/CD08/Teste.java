public class Teste {
	public static void main(String[] args) {

		
		Conta c1 = new Conta(1,12345,"Arthur",1000);
		Conta c2 = new Conta(1,12345,"Lucas");
	}
}

