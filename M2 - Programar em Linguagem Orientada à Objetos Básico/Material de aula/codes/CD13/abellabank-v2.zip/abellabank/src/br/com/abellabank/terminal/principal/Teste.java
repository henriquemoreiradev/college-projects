package br.com.abellabank.terminal.principal;

import javax.swing.JOptionPane;

import br.com.abellabank.terminal.entidades.*;
import br.com.abellabank.terminal.exceptions.SaldoInsuficienteException;
import br.com.abellabank.terminal.exceptions.ValorInvalidoException;

public class Teste {

	public static void main(String[] args) {

		Funcionario gerenteSouza = new Funcionario(1, 12000, "Souza", CargoFuncionario.GERENTE);
		Banco abellaBank = new Banco(gerenteSouza,"Rua ABC 123");
		
		//1. Listar as Contas, 2. Adicionar uma Conta, 3. Pesquisar uma Conta pelo Numero da Conta, 4. Encerrar uma Conta, 5 Sacar, 6 Depositar, 7 Sair
		
		int opcao = 1;
		
		do {
			
			JOptionPane.showMessageDialog(null, "AbellaBank \n Opcoes 1 Listar, 2 Add, 3 Pesquisa por NroConta 4. Encerra Conta por Nro, 5. Sacar, 6 Depositar, 7 Sair");
			String opcaoStr = JOptionPane.showInputDialog("Digite a sua opção: ");
			opcao = Integer.parseInt(opcaoStr);
			
			if(opcao == 1) {
				abellaBank.listarContas();
			} else if(opcao == 2) {
				
				String numeroAgenciaStr = JOptionPane.showInputDialog("Digite o numero da agencia: ");
				int numeroAgencia = Integer.parseInt(numeroAgenciaStr);
				
				String numeroContaStr = JOptionPane.showInputDialog("Digite o numero da conta: ");
				int numeroConta = Integer.parseInt(numeroContaStr);

				String titular = JOptionPane.showInputDialog("Digite o nome do titular: ");
				
				String tipoContaStr = JOptionPane.showInputDialog("Digite o tipo da conta (1 para CC, 2 CP): ");
				int tipoConta = Integer.parseInt(tipoContaStr);
				
				Conta novaConta = null;
				
				if(tipoConta == 1) {
					novaConta = new ContaCorrente(numeroAgencia, numeroConta, titular);
				} else if(tipoConta == 2) {
					
					String jurosStr = JOptionPane.showInputDialog("Digite o valor do juros");
					double juros = Double.parseDouble(jurosStr);
					
					novaConta = new ContaPoupanca(numeroAgencia, numeroConta, titular, juros);
				} else {
					JOptionPane.showMessageDialog(null, "Opção Inválida!");
				}
				
				if(novaConta != null) {
					abellaBank.abrirConta(novaConta);
					JOptionPane.showMessageDialog(null, "Conta Criada com Sucesso!");
				}
			
			} else if(opcao == 3) {
				
				String numeroContaStr = JOptionPane.showInputDialog("Digite o numero da conta a ser pesquisada: ");
				int numeroConta = Integer.parseInt(numeroContaStr);

				Conta contaPesquisada = abellaBank.pesquisarContaPeloNumeroConta(numeroConta);
				
				if(contaPesquisada == null) {
					JOptionPane.showMessageDialog(null, "Conta Não Encontrada!");	
				} else {
					JOptionPane.showMessageDialog(null, "Conta Encontrada! \n Titular: " + contaPesquisada.getTitular() + " Agencia " + contaPesquisada.getNumeroAgencia() + " Saldo " + contaPesquisada.getExtrato()); 
				}
			
			} else if(opcao == 4) {
				
				String numeroContaStr = JOptionPane.showInputDialog("Digite o numero da conta a ser encerrado: ");
				int numeroConta = Integer.parseInt(numeroContaStr);

				Conta contaPesquisada = abellaBank.pesquisarContaPeloNumeroConta(numeroConta);
				
				if(contaPesquisada == null) {
					JOptionPane.showMessageDialog(null, "Conta Não Encontrada!");	
				} else {
					abellaBank.removerConta(contaPesquisada);
					JOptionPane.showMessageDialog(null, "Conta Encerrada com Sucesso!");
				}
			
			} else if(opcao == 5) {
				
				String numeroContaStr = JOptionPane.showInputDialog("Digite o numero da conta a ser pesquisada: ");
				int numeroConta = Integer.parseInt(numeroContaStr);

				Conta contaPesquisada = abellaBank.pesquisarContaPeloNumeroConta(numeroConta);
				
				if(contaPesquisada == null) {
					JOptionPane.showMessageDialog(null, "Conta Não Encontrada!");	
				} else {
					
					String valorSaqueStr = JOptionPane.showInputDialog("Sr(a) " + contaPesquisada.getTitular() + ", quanto vc quer sacar? Seu saldo eh " +contaPesquisada.getExtrato());
					double valorSaque = Double.parseDouble(valorSaqueStr);

					try {
						contaPesquisada.sacar(valorSaque);
					} catch (ValorInvalidoException e) {
						JOptionPane.showMessageDialog(null, "Você informou um valor invalido!");
					} catch (SaldoInsuficienteException e) {
						JOptionPane.showMessageDialog(null, "Tais liso!");
					}
					
					JOptionPane.showMessageDialog(null, "Operação Encerrada!");
				}
				
			}else if(opcao == 6) {
				
				String numeroContaStr = JOptionPane.showInputDialog("Digite o numero da conta a ser pesquisada: ");
				int numeroConta = Integer.parseInt(numeroContaStr);

				Conta contaPesquisada = abellaBank.pesquisarContaPeloNumeroConta(numeroConta);
				
				if(contaPesquisada == null) {
					JOptionPane.showMessageDialog(null, "Conta Não Encontrada!");	
				} else {
					
					String valorDepositoStr = JOptionPane.showInputDialog("Sr(a) " + contaPesquisada.getTitular() + ", quanto vc quer depositar?");
					double valorDeposito = Double.parseDouble(valorDepositoStr);

					try {
						contaPesquisada.depositar(valorDeposito);
					} catch (ValorInvalidoException e) {
						JOptionPane.showMessageDialog(null, "Você informou um valor invalido!");
					}
					
					JOptionPane.showMessageDialog(null, "Operação Encerrada!");
				}				
			}
			
		} while(opcao != 7);
		
		
		JOptionPane.showMessageDialog(null, "AbellaBank Agradece seu Dinheiro! ");
	}

}
