package br.com.abellabank.terminal.exceptions;

public class SaldoInsuficienteException extends Exception {

	public SaldoInsuficienteException() {
		super();
	}

	public SaldoInsuficienteException(String message) {
		super(message);
	}

	
	
}
