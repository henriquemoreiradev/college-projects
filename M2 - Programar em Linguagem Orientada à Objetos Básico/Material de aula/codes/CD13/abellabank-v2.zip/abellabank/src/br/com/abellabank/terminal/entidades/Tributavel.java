package br.com.abellabank.terminal.entidades;

public interface Tributavel {

	double TRIBUTO_MINIMO = 2.0;
	
	double getTributo();
}
