package br.com.abellabank.terminal.entidades;

public enum TipoMoeda {

	DOLAR, REAL, EURO
}
