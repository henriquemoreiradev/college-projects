package br.com.abellabank.terminal.entidades;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Banco {

	private Funcionario gerente;
	private String endereco;
	private ArrayList<Conta> contas = new ArrayList<Conta>();
	
	public Banco(Funcionario gerente, String endereco) {
		this.gerente = gerente;
		this.endereco = endereco;
	}
	
	public void abrirConta(Conta novaConta) {
		
		if(novaConta != null) {
			contas.add(novaConta);
		}
	}
	
	public Conta pesquisarContaPeloNumeroConta(int numeroConta) {
		
		Conta contaPesquisada = null;
		
		for (Conta contaTemp : contas) {
			
			if(contaTemp.getNumeroConta() == numeroConta) {
				contaPesquisada = contaTemp;
				break;
			}
		}
		
		return contaPesquisada;
	}
	
	public void removerConta(Conta contaParaRemover) {
		contas.remove(contaParaRemover);
	}
	
	public void listarContas() {
		
		if(contas.isEmpty()) {
			JOptionPane.showMessageDialog(null, "Não existem contas a serem exibidas!");
		} else {
			String textoListaContas = "Lista de Contas do AbellaBank \n";
			for (Conta conta : contas) {
				textoListaContas += "Titular: " + conta.getTitular() + " Numero da Conta: " + conta.getNumeroConta() + "\n"; 
			}
			
			JOptionPane.showMessageDialog(null, textoListaContas);
		}
	}

	public Funcionario getGerente() {
		return gerente;
	}

	public void setGerente(Funcionario gerente) {
		this.gerente = gerente;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public ArrayList<Conta> getContas() {
		return contas;
	}

	
	
	
	
}
