package br.com.abellabank.terminal.entidades;

public enum CargoFuncionario {

	GERENTE, CAIXA, ATENDENTE, SUPERVISOR, DIRETOR
}
