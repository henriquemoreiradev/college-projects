package br.com.abellabank.terminal.exceptions;

public class ValorInvalidoException extends Exception {

	public ValorInvalidoException() {
		super();
	}

	public ValorInvalidoException(String message) {
		super(message);
	}

	
	
}
