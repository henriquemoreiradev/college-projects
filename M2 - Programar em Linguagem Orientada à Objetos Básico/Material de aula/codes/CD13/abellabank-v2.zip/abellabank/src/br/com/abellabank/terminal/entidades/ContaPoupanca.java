package br.com.abellabank.terminal.entidades;

import br.com.abellabank.terminal.exceptions.SaldoInsuficienteException;
import br.com.abellabank.terminal.exceptions.ValorInvalidoException;

public final class ContaPoupanca extends Conta {

	private static final double IMPOSTO_SAQUE_CONTA_POUPANCA = 1.2;
	private double juros;

	public ContaPoupanca(int numeroAgencia, int numeroConta, String titular, double juros) {
		super(numeroAgencia, numeroConta, titular);
		this.juros = juros;
	}

	public ContaPoupanca(int numeroAgencia, int numeroConta, String titular, double saldo, double juros) {
		super(numeroAgencia, numeroConta, titular, saldo);
		this.juros = juros;
	}
	
	@Override
	public void sacar(double montante) throws ValorInvalidoException, SaldoInsuficienteException {
		montante =+ IMPOSTO_SAQUE_CONTA_POUPANCA;
		super.sacar(montante);
	}
	

	public double getJuros() {
		return juros;
	}

	public void setJuros(double juros) {
		this.juros = juros;
	}
	
	
	
}
